#include <project.h>
#include <stdint.h>
#include "directions.h"

/* ================================
 * Robot-specific PWM + enable
 *  - Clock_PWM, PWM_1, PWM_2
 *  - CONTROL pin: LOW = enable
 *  - Sign map (typical from your build):
 *      LEFT  forward  = +duty
 *      RIGHT forward  = -duty
 *    -> Pivot LEFT  = left reverse,  right forward
 *    -> Pivot RIGHT = right reverse, left  forward
 * Adjust RIGHT/LEFT signs below if your wiring differs.
 * ================================ */

/* ===== Tunables (start here, then fine-tune on floor) ===== */
#define TURN_SPEED_PC        28      // 10..40%
#define TURN_TIME_MS         450     // ~90° at TURN_SPEED_PC (tune ±20–60 ms)
#define STOP_BEFORE_MS       80      // settle before pivot
#define BRAKE_AFTER_MS       90      // quick brake after pivot
#define PWM_PERIOD_TICKS     200u    // must match your PWM config

/* NEW: small holdoff before we start the pivot.
 * Lets straight-line control run ~10 ms longer after detection. */
#define TURN_START_DELAY_MS  70

/* Polarity (forward direction) */
#define RIGHT_MOTOR_SIGN     (-1)
#define LEFT_MOTOR_SIGN      (+1)

/* Map [-100..100] -> PWM compare around mid */
static inline uint16_t duty_to_compare(int s){
    if (s < -100) s = -100; if (s > 100) s = 100;
    return (uint16_t)((PWM_PERIOD_TICKS/2) + ((int32)PWM_PERIOD_TICKS * s)/200);
}

static inline void motors_enable_on(void){
    CONTROL_Write(0x00);            // both LOW -> enable drivers
    Clock_PWM_Start();
    PWM_1_Start(); PWM_2_Start();
    PWM_1_WritePeriod(PWM_PERIOD_TICKS);
    PWM_2_WritePeriod(PWM_PERIOD_TICKS);
}

static inline void set_raw_percent(int duty_right, int duty_left){
    PWM_1_WriteCompare(duty_to_compare(RIGHT_MOTOR_SIGN * duty_right));
    PWM_2_WriteCompare(duty_to_compare(LEFT_MOTOR_SIGN  * duty_left));
}

static void brake_quick(uint16_t ms, int base_pc){
    int d = (base_pc < 8) ? 8 : base_pc;
    set_raw_percent(-d, -d);
    CyDelay(ms);
}

void Directions_Init(void){
    // nothing needed; safe to call anytime
}

bool Directions_IsBusy(void){
    return false; // blocking implementation
}

//static void pivot_left_blocking(void){
 //   motors_enable_on();
 //   set_raw_percent(0, 0);
 //   CyDelay(STOP_BEFORE_MS);

    // LEFT pivot: right fwd, left rev
 //   set_raw_percent(+TURN_SPEED_PC, -TURN_SPEED_PC);
 //   CyDelay(TURN_TIME_MS);

 //   brake_quick(BRAKE_AFTER_MS, TURN_SPEED_PC);
 //   set_raw_percent(0, 0);
//}

//static void pivot_right_blocking(void){
//    motors_enable_on();
//    set_raw_percent(0, 0);
 //   CyDelay(STOP_BEFORE_MS);

    // RIGHT pivot: right rev, left fwd
 //   set_raw_percent(-TURN_SPEED_PC, +TURN_SPEED_PC);
 //   CyDelay(TURN_TIME_MS);

 //   brake_quick(BRAKE_AFTER_MS, TURN_SPEED_PC);
 //   set_raw_percent(0, 0);
//}

void Directions_Handle(volatile uint8_t* gdir){
    if (!gdir) return;
    uint8_t d = *gdir;
    if (d == 0u) return;   // only act when asked

    /* NEW: brief delay before taking control — lets Motor_ControlStep()
       keep driving straight for a hair longer after detection. */
    CyDelay(TURN_START_DELAY_MS);

    if (d == 1u){
        motors_enable_on();
        set_raw_percent(0, 0);
        CyDelay(STOP_BEFORE_MS);

        // LEFT pivot: right fwd, left rev
        set_raw_percent(+TURN_SPEED_PC, -TURN_SPEED_PC);
        CyDelay(TURN_TIME_MS);

        brake_quick(BRAKE_AFTER_MS, TURN_SPEED_PC);
        set_raw_percent(0, 0);
    } else if (d == 2u){
         motors_enable_on();
        set_raw_percent(0, 0);
        CyDelay(STOP_BEFORE_MS);

        // RIGHT pivot: right rev, left fwd
        set_raw_percent(-TURN_SPEED_PC, +TURN_SPEED_PC);
        CyDelay(TURN_TIME_MS);

        brake_quick(BRAKE_AFTER_MS, TURN_SPEED_PC);
        set_raw_percent(0, 0);
    }

    *gdir = 0u;            // back to straight mode
}
